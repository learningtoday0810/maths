n = int(input("Enter n: "))
print(f"\nEnter the {n} coefficients for each row:")
A = []
for i in range(n):
    row = list(map(float, input(f"Row {i+1}: ").split()))
    A.append(row)
print("\nEnter the RHS Vector B:")
B = list(map(float, input("Vector B: ").split()))


def solve_gauss(A_in, B_in):
    n = len(B_in)
    M = [A_in[i] + [B_in[i]] for i in range(n)]
    for i in range(n):
        max_row = max(range(i, n), key=lambda r: abs(M[r][i]))
        M[i], M[max_row] = M[max_row], M[i]
        for k in range(i+1, n):
            factor = M[k][i] / M[i][i]
            for j in range(i, n+1):
                M[k][j] -= factor * M[i][j]
    x = [0.0]*n
    for i in range(n-1, -1, -1):
        s = sum(M[i][j]*x[j] for j in range(i+1, n))
        x[i] = (M[i][n]-s)/M[i][i]
    return x


def solve_jacobi(A_in, B_in, tol=0.0001, max_iter=1000):
    n = len(B_in)
    x = [0.0]*n
    for k in range(max_iter):
        x_new = [0.0]*n
        for i in range(n):
            s = sum(A_in[i][j]*x[j] for j in range(n) if j != i)
            x_new[i] = (B_in[i]-s)/A_in[i][i]
        if max(abs(x_new[i]-x[i]) for i in range(n)) < tol:
            return x_new, k+1
        x = x_new[:]
    return x, max_iter


def solve_seidel(A_in, B_in, tol=0.0001, max_iter=1000):
    n = len(B_in)
    x = [0.0]*n
    for k in range(max_iter):
        x_old = x[:]
        for i in range(n):
            s1 = sum(A_in[i][j]*x[j] for j in range(i))
            s2 = sum(A_in[i][j]*x_old[j] for j in range(i+1, n))
            x[i] = (B_in[i]-s1-s2)/A_in[i][i]
        if max(abs(x[i]-x_old[i]) for i in range(n)) < tol:
            return x, k+1
    return x, max_iter


v_gauss = solve_gauss(A, B)
v_jacobi, iter_j = solve_jacobi(A, B)
v_seidel, iter_s = solve_seidel(A, B)
print("Gauss Elimination:")
print([round(v, 4) for v in v_gauss])
print("\nGauss-Jacobi:")
print("Iterations:", iter_j)
print([round(v, 4) for v in v_jacobi])
print("\nGauss-Seidel:")
print("Iterations:", iter_s)
print([round(v, 4) for v in v_seidel])
