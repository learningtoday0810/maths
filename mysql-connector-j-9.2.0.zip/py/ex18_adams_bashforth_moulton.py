import math
import re

math_env = {
    "sin": math.sin, "cos": math.cos, "tan": math.tan,
    "exp": math.exp, "sqrt": math.sqrt, "log": math.log,
    "pi": math.pi, "e": math.e
}

def clean_expression(raw_expr):
    if "=" in raw_expr:
        raw_expr = raw_expr.split("=")[-1]
    expr = re.sub(r'(\))\s*([a-zA-Z0-9(])', r'\1*\2', raw_expr)
    expr = re.sub(r'(\d)\s*([a-zA-Z(])', r'\1*\2', expr)
    return expr.strip()

print("=" * 60)
print("     UNIVERSAL ADAMS PREDICTOR-CORRECTOR SOLVER     ")
print("=" * 60)

raw_expr = input("Enter equation f(x, y) [e.g. x + y, x - y**2, x*y + 1]: ")
parsed_expr = clean_expression(raw_expr)
print(f"Interpreted equation: dy/dx = {parsed_expr}\n")

def f(x, y):
    env = math_env.copy()
    env["x"] = x
    env["y"] = y
    return eval(parsed_expr, {"__builtins__": {}}, env)

print("How is your problem given?")
print("1. Only (x0, y0) is given -> Compute y1, y2, y3 via RK4 first")
print("2. 4 points (x0..x3, y0..y3) are already given in the question")
mode = input("Enter choice (1 or 2): ").strip()

x_vals = []
y_vals = []

if mode == "1":
    x0 = float(input("\nEnter x0: "))
    y0 = float(input("Enter y0: "))
    h = float(input("Enter step size h: "))
    xf = float(input("Enter target x to find: "))

    total_steps = int(round((xf - x0) / h))
    if total_steps < 4:
        print(f"\n[NOTE]: You want x = {xf}, which is only step {total_steps}.")
        print("Adams requires at least 4 past steps to work.")
        print("Computing the answer using RK4 instead:")
        x_curr, y_curr = x0, y0
        for i in range(total_steps):
            k1 = h * f(x_curr, y_curr)
            k2 = h * f(x_curr + h/2, y_curr + k1/2)
            k3 = h * f(x_curr + h/2, y_curr + k2/2)
            k4 = h * f(x_curr + h, y_curr + k3)
            y_curr += (k1 + 2*k2 + 2*k3 + k4) / 6.0
            x_curr += h
            print(f"  Step {i+1}: y({x_curr:.4f}) = {y_curr:.6f}")
        raise SystemExit

    x_vals = [x0 + i * h for i in range(total_steps + 1)]
    y_vals = [0.0] * (total_steps + 1)
    y_vals[0] = y0

    # Starter: Compute y1, y2, y3 using RK4
    print("\n--- Generating Starter Points (y1, y2, y3) using RK4 ---")
    for i in range(3):
        k1 = h * f(x_vals[i], y_vals[i])
        k2 = h * f(x_vals[i] + h / 2.0, y_vals[i] + k1 / 2.0)
        k3 = h * f(x_vals[i] + h / 2.0, y_vals[i] + k2 / 2.0)
        k4 = h * f(x_vals[i] + h, y_vals[i] + k3)
        y_vals[i + 1] = y_vals[i] + (k1 + 2 * k2 + 2 * k3 + k4) / 6.0
        print(f"  x[{i+1}] = {x_vals[i+1]:.4f} -> y[{i+1}] = {y_vals[i+1]:.6f}")

elif mode == "2":
    h = float(input("\nEnter step size h: "))
    print("Enter the 4 known points (x, y):")
    for i in range(4):
        xi = float(input(f"  x[{i}]: "))
        yi = float(input(f"  y[{i}]: "))
        x_vals.append(xi)
        y_vals.append(yi)

    xf = float(input("Enter final target x to find: "))
    total_steps = int(round((xf - x_vals[0]) / h))
    for i in range(4, total_steps + 1):
        x_vals.append(x_vals[0] + i * h)
        y_vals.append(0.0)

# Evaluate f(x, y) for all points
f_vals = [f(x_vals[i], y_vals[i]) for i in range(4)] + [0.0] * (len(x_vals) - 4)

print("\n" + "=" * 65)
print("     ADAMS-BASHFORTH PREDICTOR-CORRECTOR ITERATIONS")
print("=" * 65)
print(f"{'Target x':<10} | {'Predictor (y_p)':<18} | {'Corrector (y_c)':<18}")
print("-" * 65)

# Adams calculation starts from index 3 to predict index 4 onwards
for n in range(3, total_steps):
    target_x = x_vals[n + 1]

    # Adams-Bashforth Predictor
    y_pred = y_vals[n] + (h / 24.0) * (
        55.0 * f_vals[n] - 59.0 * f_vals[n - 1] + 37.0 * f_vals[n - 2] - 9.0 * f_vals[n - 3]
    )

    # Adams-Moulton Corrector
    fn_next = f(target_x, y_pred)
    y_corr = y_vals[n] + (h / 24.0) * (
        9.0 * fn_next + 19.0 * f_vals[n] - 5.0 * f_vals[n - 1] + f_vals[n - 2]
    )

    y_vals[n + 1] = y_corr
    f_vals[n + 1] = f(target_x, y_corr)

    print(f"{target_x:<10.4f} | {y_pred:<18.6f} | {y_corr:<18.6f}")

print("=" * 65)
print(f"\nFinal Result: y({xf:.4f}) = {y_vals[-1]:.6f}")