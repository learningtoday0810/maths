import math

math_namespace = {
    "sin": math.sin, "cos": math.cos, "tan": math.tan,
    "exp": math.exp, "sqrt": math.sqrt, "log": math.log,
    "pi": math.pi, "e": math.e,
}

print("Choose input mode:")
print("1. Enter a mathematical equation f(x)")
print("2. Enter a table of y values directly (e.g. river depth problem)")
choice = input("Enter choice (1 or 2): ").strip()

if choice == "1":
    expr_str = input("\nEnter equation in terms of x (e.g., x**2, sin(x), 1/(1+x**2)): ")
    
    def f(x):
        env = math_namespace.copy()
        env["x"] = x
        return eval(expr_str, {"__builtins__": {}}, env)

    a = float(input("Enter lower limit (a): "))
    b = float(input("Enter upper limit (b): "))
    n = int(input("Enter number of sub-intervals (n): "))

    h = (b - a) / n
    x_vals = [a + i * h for i in range(n + 1)]
    y_vals = [f(x) for x in x_vals]

elif choice == "2":
    print("\nEnter the y values separated by spaces or commas:")
    raw_y = input("y values: ").replace(",", " ")
    y_vals = [float(val) for val in raw_y.split()]

    h = float(input("Enter step size (h) [e.g. 10]: "))
    n = len(y_vals) - 1
    
    x_start = float(input("Enter starting x value (x0) [e.g. 0]: ") or 0)
    x_vals = [x_start + i * h for i in range(n + 1)]

else:
    print("Invalid choice. Please run again and select 1 or 2.")
    raise SystemExit

# --- Display Values of x and f(x) / y ---
print("\n" + "=" * 32)
print(f"{'i':<4} | {'x':<10} | {'y = f(x)':<12}")
print("-" * 32)
for i in range(n + 1):
    print(f"{i:<4} | {x_vals[i]:<10.4f} | {y_vals[i]:<12.6f}")
print("=" * 32)

# --- Compute Trapezoidal Rule ---
total = (y_vals[0] + y_vals[-1]) + 2 * sum(y_vals[1:-1])
result = (h / 2) * total

print(f"\nStep size (h)        : {h}")
print(f"Number of intervals  : {n}")
print(f"Trapezoidal Result   : {result:.6f}")