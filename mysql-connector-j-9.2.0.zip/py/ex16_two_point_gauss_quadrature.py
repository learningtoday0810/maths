import math

math_namespace = {
    "sin": math.sin, "cos": math.cos, "tan": math.tan,
    "exp": math.exp, "sqrt": math.sqrt, "log": math.log,
    "pi": math.pi, "e": math.e,
}

print("=== Gauss-Legendre 2-Point Quadrature ===")
expr_str = input("Enter equation in terms of x (e.g., x**2, 1/(1+x**2), exp(-x**2)): ")

def f(x):
    env = math_namespace.copy()
    env["x"] = x
    return eval(expr_str, {"__builtins__": {}}, env)

a = float(input("Enter lower limit (a): "))
b = float(input("Enter upper limit (b): "))
m = int(input("Enter number of subintervals (m): "))

# Standard Gauss-Legendre 2-point nodes and weights on [-1, 1]
t1 = -1.0 / math.sqrt(3)
t2 = 1.0 / math.sqrt(3)
w1 = 1.0
w2 = 1.0

h = (b - a) / m
total = 0.0

print("\n" + "=" * 65)
print(f"{'Subinterval':<15} | {'p1 (x)':<10} | {'f(p1)':<10} | {'p2 (x)':<10} | {'f(p2)':<10}")
print("-" * 65)

for i in range(m):
    x_start = a + i * h
    x_end = x_start + h
    mid = (x_start + x_end) / 2.0
    half_w = (x_end - x_start) / 2.0
    
    p1 = mid + half_w * t1
    p2 = mid + half_w * t2
    
    f_p1 = f(p1)
    f_p2 = f(p2)
    
    interval_label = f"[{x_start:.2f}, {x_end:.2f}]"
    print(f"{interval_label:<15} | {p1:<10.4f} | {f_p1:<10.4f} | {p2:<10.4f} | {f_p2:<10.4f}")
    
    total += half_w * (w1 * f_p1 + w2 * f_p2)

print("=" * 65)
print(f"\nSubinterval width (h) : {h:.6f}")
print(f"Total subintervals (m) : {m}")
print(f"Gauss 2-Point Result   : {total:.6f}")