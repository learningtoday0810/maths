def backward_interpolation(x, y, value):
    n = len(x)
    h = x[1] - x[0]
    for i in range(1, n - 1):
        if abs((x[i + 1] - x[i]) - h) > 1e-10:
            print("Error: x values must be equally spaced.")
            return None
    diff = [[0.0 for _ in range(n)] for _ in range(n)]
    for i in range(n):
        diff[i][0] = y[i]
    for j in range(1, n):
        for i in range(j, n):
            diff[i][j] = diff[i][j - 1] - diff[i - 1][j - 1]
    print("\nBackward Difference Table:")
    print(f"{'x':>10} {'y':>10}", end="")
    for j in range(1, n):
        print(f"{'∇' + str(j):>10}", end="")
    print()
    for i in range(n):
        print(f"{x[i]:>10.4f}", end="")
        print(f"{diff[i][0]:>10.4f}", end="")
        for j in range(1, n):
            if i >= j:
                print(f"{diff[i][j]:>10.4f}", end="")
            else:
                print(f"{'':>10}", end="")
        print()
    u = (value - x[n - 1]) / h
    result = y[n - 1]
    term = 1
    for i in range(1, n):
        term *= (u + (i - 1))
        term /= i
        result += term * diff[n - 1][i]
    return result


n = int(input("Enter the number of data points: "))
x = []
y = []
print("Enter the x values:")
for i in range(n):
    x.append(float(input(f"x[{i}] = ")))
print("Enter the y values:")
for i in range(n):
    y.append(float(input(f"y[{i}] = ")))
value = float(input("Enter the value of x to interpolate: "))
answer = backward_interpolation(x, y, value)
if answer is not None:
    print(f"\nInterpolated value at x = {value} is {answer:.4f}")
