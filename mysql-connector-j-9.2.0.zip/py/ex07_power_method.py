def power_method():
    n = int(input("Enter the order of matrix: "))
    A = []
    print("Enter the matrix row-wise:")
    for i in range(n):
        A.append(list(map(float, input().split())))
    print("Enter the initial vector:")
    V = list(map(float, input().split()))
    tol = 0.0001
    lam = 0
    iteration = 1
    while True:
        W = []
        for i in range(n):
            s = 0
            for j in range(n):
                s += A[i][j] * V[j]
            W.append(s)
        c1 = abs(W[0])
        for i in range(1, n):
            if abs(W[i]) > c1:
                c1 = abs(W[i])
        for i in range(n):
            W[i] = W[i] / c1
        lambda_error = abs(c1 - lam)
        sum_error = 0
        for i in range(n):
            sum_error += (V[i] - W[i]) ** 2
        eigen_error = sum_error ** 0.5
        error = max(lambda_error, eigen_error)
        V = W[:]
        lam = c1
        print("\nIteration", iteration)
        print("Eigen Value =", round(lam, 4))
        print("Eigen Vector =", end=" ")
        print([round(x, 4) for x in V])
        if error <= tol:
            break
        iteration += 1
    print("\nDominant Eigen Value =", round(lam, 4))
    print("Associated Eigen Vector =", end=" ")
    print([round(x, 4) for x in V])


power_method()
