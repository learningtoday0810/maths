import numpy as np
import re
import math

math_env = {
    "sin": math.sin, "cos": math.cos, "tan": math.tan,
    "exp": math.exp, "sqrt": math.sqrt, "log": math.log,
    "pi": math.pi, "e": math.e
}

def clean_expression(raw_expr):
    if "=" in raw_expr:
        raw_expr = raw_expr.split("=")[-1]
    expr = re.sub(r'(\))\s*([a-zA-Z0-9(])', r'\1*\2', raw_expr)
    expr = re.sub(r'(\d)\s*([a-zA-Z(])', r'\1*\2', expr)
    return expr.strip()

print("=" * 65)
print("   CRANK-NICOLSON IMPLICIT SOLVER (u_t = alpha * u_xx)        ")
print("=" * 65)

# Domain and Grid Parameters
L = float(input("Enter domain length L (e.g. 1.0): "))
T = float(input("Enter total simulation time T (e.g. 1.0): "))
alpha = float(input("Enter thermal diffusivity alpha (e.g. 0.01 or 1.0): "))
M = int(input("Enter number of spatial subintervals M (e.g. 4): "))
N = int(input("Enter number of time steps N (e.g. 2): "))

h = L / M
k = T / N
r = (alpha * k) / (h**2)
x_nodes = np.linspace(0, L, M + 1)

print(f"\nMesh Properties:")
print(f"  h = {h:.4f},  k = {k:.4f},  Mesh ratio r = {r:.4f}")
print("  [INFO]: Crank-Nicolson is unconditionally stable for any r > 0.")

# Boundary Conditions
print("\n--- Boundary Conditions ---")
left_bc = clean_expression(input("Enter left boundary u(0, t) [e.g. 0]: ") or "0")
right_bc = clean_expression(input(f"Enter right boundary u({L}, t) [e.g. 0]: ") or "0")

def g0(t_val):
    env = math_env.copy()
    env["t"] = t_val
    return float(eval(left_bc, {"__builtins__": {}}, env))

def gL(t_val):
    env = math_env.copy()
    env["t"] = t_val
    return float(eval(right_bc, {"__builtins__": {}}, env))

# Initial Condition
print("\n--- Initial Condition u(x, 0) ---")
print("1. Enter formula (e.g. 100*sin(pi*x))")
print("2. Enter point-by-point values manually")
init_choice = input("Select choice (1 or 2): ").strip()

u = np.zeros((N + 1, M + 1))

if init_choice == "1":
    init_expr = clean_expression(input("Enter formula for u(x, 0): "))
    for i in range(M + 1):
        env = math_env.copy()
        env["x"] = x_nodes[i]
        u[0, i] = float(eval(init_expr, {"__builtins__": {}}, env))
else:
    print(f"Enter {M + 1} values for initial distribution u(x, 0):")
    for i in range(M + 1):
        u[0, i] = float(input(f"  u(x = {x_nodes[i]:.4f}, 0): "))

# Enforce boundaries at t = 0
u[0, 0] = g0(0.0)
u[0, M] = gL(0.0)

# Build Tridiagonal Matrices A and B
dim = M - 1  # interior unknowns count
A = np.zeros((dim, dim))
B = np.zeros((dim, dim))

for i in range(dim):
    A[i, i] = 1.0 + r
    B[i, i] = 1.0 - r
    if i > 0:
        A[i, i - 1] = -r / 2.0
        B[i, i - 1] = r / 2.0
    if i < dim - 1:
        A[i, i + 1] = -r / 2.0
        B[i, i + 1] = r / 2.0

# Crank-Nicolson Time Marching Loop
for n in range(N):
    t_curr = n * k
    t_next = (n + 1) * k
    
    u[n + 1, 0] = g0(t_next)
    u[n + 1, M] = gL(t_next)
    
    # Compute Right-Hand Side Vector
    rhs = B @ u[n, 1:M]
    rhs[0] += (r / 2.0) * (u[n, 0] + u[n + 1, 0])
    rhs[-1] += (r / 2.0) * (u[n, M] + u[n + 1, M])
    
    # Solve linear tridiagonal system for time level n + 1
    u[n + 1, 1:M] = np.linalg.solve(A, rhs)

# Display Result Grid
header = f"{'Time Level':<12} | " + " | ".join([f"x={x_nodes[i]:<6.3f}" for i in range(M + 1)])
print("\n" + "=" * len(header))
print("          CRANK-NICOLSON SOLUTION TABLE: u(x, t)          ")
print("=" * len(header))
print(header)
print("-" * len(header))
for n in range(N, -1, -1):
    t_val = n * k
    row_str = " | ".join([f"{u[n, i]:8.4f}" for i in range(M + 1)])
    print(f"n={n:<2} (t={t_val:.3f}) | {row_str}")
print("=" * len(header))