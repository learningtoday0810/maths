def gauss_jacobi():
    n = int(input("Enter size of system (n): "))
    print("\nEnter matrix A:")
    A = []
    for i in range(n):
        row = list(map(float, input(f"Row {i+1}: ").split()))
        A.append(row)
    print("\nEnter vector b (space-separated):")
    b = list(map(float, input(f"b ({n} values): ").split()))
    x0 = [0.0] * n
    TOL = 0.0001
    KMAX = 100
    Oldx = list(x0)
    print(Oldx)
    Newx = [0.0] * n
    TAG = True
    k = 1
    print(f"\nInitial Guess x(0): {Oldx}\n")
    while k <= KMAX and TAG:
        for i in range(n):
            sum_val = sum(A[i][j] * Oldx[j] for j in range(n) if j != i)
            # Formula: Newx_i = [b_i - sum(a_ij * Oldx_j)] / a_ii
            Newx[i] = (b[i] - sum_val) / A[i][i]
        error = max(abs(Newx[i] - Oldx[i]) for i in range(n))
        print(f"Iteration {k}: {[round(val, 5) for val in Newx]} | Error: {round(error, 5)}")
        if error <= TOL:
            TAG = False
            print(f"\n[SUCCESS] Converged at iteration {k} (Tolerance <= {TOL})")
        else:
            Oldx = list(Newx)
        k += 1
    if TAG:
        print("\n[STOP] Reached maximum iterations without fully converging.")
    print("\nFinal Solution:")
    for i in range(n):
        print(f"x_{i + 1} = {round(Newx[i], 5)}")


if __name__ == "__main__":
    gauss_jacobi()
