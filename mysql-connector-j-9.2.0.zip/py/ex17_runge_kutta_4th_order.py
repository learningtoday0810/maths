import math
import re
import matplotlib.pyplot as plt

# Math environment allowing standard functions
math_env = {
    "sin": math.sin, "cos": math.cos, "tan": math.tan,
    "exp": math.exp, "sqrt": math.sqrt, "log": math.log,
    "pi": math.pi, "e": math.e
}

def clean_expression(raw_expr):
    """Cleans up the user-typed expression for Python evaluation."""
    if "=" in raw_expr:
        raw_expr = raw_expr.split("=")[-1]
    # Replace variable p or y with y, and t with x if used
    expr = raw_expr.replace("p", "y").replace("t", "x")
    # Insert implicit multiplications: e.g., (x**2)y -> (x**2)*y, 2x -> 2*x
    expr = re.sub(r'(\))\s*([a-zA-Z0-9(])', r'\1*\2', expr)
    expr = re.sub(r'(\d)\s*([a-zA-Z(])', r'\1*\2', expr)
    return expr.strip()

print("=" * 50)
print("     1st-ORDER ODE SOLVER USING RK4 METHOD        ")
print("=" * 50)

raw_expr = input("Enter equation f(x, y) [e.g. 0.1*y, x*(x**2+y**2)*exp(-x)]: ")
parsed_expr = clean_expression(raw_expr)
print(f"Parsed equation: y' = {parsed_expr}\n")

def f(x_val, y_val):
    env = math_env.copy()
    env["x"] = x_val
    env["y"] = y_val
    return eval(parsed_expr, {"__builtins__": {}}, env)

# Collect inputs
x0 = float(input("Enter initial x (or t): "))
y0 = float(input("Enter initial y (or p): "))
h = float(input("Enter step size (h): "))
xn = float(input("Enter final target x (or tf): "))

x = x0
y = y0
step = 0

x_vals = [x]
y_vals = [y]

# Display table header
print("\n" + "=" * 70)
print(f"{'Step':<5} | {'x':<8} | {'k1':<9} | {'k2':<9} | {'k3':<9} | {'k4':<9} | {'y':<10}")
print("-" * 70)
print(f"{step:<5} | {x:<8.4f} | {'-':<9} | {'-':<9} | {'-':<9} | {'-':<9} | {y:<10.5f}")

while x + h <= xn + 1e-9:
    # 4 intermediate slopes (RK4)
    k1 = h * f(x, y)
    k2 = h * f(x + h / 2.0, y + k1 / 2.0)
    k3 = h * f(x + h / 2.0, y + k2 / 2.0)
    k4 = h * f(x + h, y + k3)

    # RK4 update formula
    y += (k1 + 2 * k2 + 2 * k3 + k4) / 6.0
    x += h
    step += 1

    x_vals.append(x)
    y_vals.append(y)

    print(f"{step:<5} | {x:<8.4f} | {k1:<9.5f} | {k2:<9.5f} | {k3:<9.5f} | {k4:<9.5f} | {y:<10.5f}")

print("=" * 70)

# Plotting the RK4 solution
plt.figure(figsize=(8, 5))
plt.plot(x_vals, y_vals, 'ro--', label=f"RK4: y' = {parsed_expr}")
plt.xlabel("x")
plt.ylabel("y")
plt.title("Numerical Solution of 1st-Order ODE using RK4")
plt.legend()
plt.grid(True)
plt.show()