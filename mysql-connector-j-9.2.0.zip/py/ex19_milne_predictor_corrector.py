import math
import re

math_env = {
    "sin": math.sin, "cos": math.cos, "tan": math.tan,
    "exp": math.exp, "sqrt": math.sqrt, "log": math.log,
    "pi": math.pi, "e": math.e
}

def clean_expression(raw_expr):
    """Formats raw math string to valid Python code."""
    if "=" in raw_expr:
        raw_expr = raw_expr.split("=")[-1]
    expr = re.sub(r'(\))\s*([a-zA-Z0-9(])', r'\1*\2', raw_expr)
    expr = re.sub(r'(\d)\s*([a-zA-Z(])', r'\1*\2', expr)
    return expr.strip()

print("=" * 60)
print("     MILNE'S PREDICTOR-CORRECTOR METHOD SOLVER      ")
print("=" * 60)

raw_expr = input("Enter equation f(x, y) [e.g. x + y, x - y**2]: ")
parsed_expr = clean_expression(raw_expr)
print(f"Interpreted equation: dy/dx = {parsed_expr}\n")

def f(x, y):
    env = math_env.copy()
    env["x"] = x
    env["y"] = y
    return eval(parsed_expr, {"__builtins__": {}}, env)

print("Choose how initial values are supplied:")
print("1. Only (x0, y0) given -> compute y1, y2, y3 using RK4 first")
print("2. Enter 4 known points (x0..x3, y0..y3) directly from question")
choice = input("Enter choice (1 or 2): ").strip()

x_vals = []
y_vals = []

if choice == "1":
    x0 = float(input("\nEnter initial x0: "))
    y0 = float(input("Enter initial y0: "))
    h = float(input("Enter step size (h): "))
    xf = float(input("Enter target final x: "))

    total_steps = int(round((xf - x0) / h))
    if total_steps < 4:
        print(f"\nTarget x = {xf} is step {total_steps}. Milne's method requires at least 4 prior steps.")
        print("Computing result directly via RK4:")
        cur_x, cur_y = x0, y0
        for i in range(total_steps):
            k1 = h * f(cur_x, cur_y)
            k2 = h * f(cur_x + h/2.0, cur_y + k1/2.0)
            k3 = h * f(cur_x + h/2.0, cur_y + k2/2.0)
            k4 = h * f(cur_x + h, cur_y + k3)
            cur_y += (k1 + 2*k2 + 2*k3 + k4) / 6.0
            cur_x += h
            print(f"  Step {i+1}: y({cur_x:.4f}) = {cur_y:.6f}")
        raise SystemExit

    x_vals = [x0 + i * h for i in range(total_steps + 1)]
    y_vals = [0.0] * (total_steps + 1)
    y_vals[0] = y0

    print("\n--- Starting 4 Points (RK4) ---")
    print(f"  x[0] = {x_vals[0]:.4f} -> y[0] = {y_vals[0]:.6f}")
    for i in range(3):
        k1 = h * f(x_vals[i], y_vals[i])
        k2 = h * f(x_vals[i] + h / 2.0, y_vals[i] + k1 / 2.0)
        k3 = h * f(x_vals[i] + h / 2.0, y_vals[i] + k2 / 2.0)
        k4 = h * f(x_vals[i] + h, y_vals[i] + k3)
        y_vals[i + 1] = y_vals[i] + (k1 + 2*k2 + 2*k3 + k4) / 6.0
        print(f"  x[{i+1}] = {x_vals[i+1]:.4f} -> y[{i+1}] = {y_vals[i+1]:.6f}")

elif choice == "2":
    h = float(input("\nEnter step size (h): "))
    print("Enter the 4 starting points:")
    for i in range(4):
        xi = float(input(f"  Enter x[{i}]: "))
        yi = float(input(f"  Enter y[{i}]: "))
        x_vals.append(xi)
        y_vals.append(yi)

    xf = float(input("Enter final target x: "))
    total_steps = int(round((xf - x_vals[0]) / h))
    for i in range(4, total_steps + 1):
        x_vals.append(x_vals[0] + i * h)
        y_vals.append(0.0)

else:
    print("Invalid choice. Please run again.")
    raise SystemExit

# Optional tolerance input
eps_input = input("\nEnter tolerance for corrector (press Enter for single exam step): ").strip()
eps = float(eps_input) if eps_input else None

# Slopes array
F = [f(x_vals[i], y_vals[i]) for i in range(4)] + [0.0] * (total_steps - 3)

print("\n" + "=" * 65)
print(f"{'Target x':<10} | {'Predictor (y_p)':<18} | {'Corrector (y_c)':<18}")
print("-" * 65)

# Milne's Predictor-Corrector Loop
for n in range(3, total_steps):
    target_x = x_vals[n + 1]

    # Milne's Predictor: y_{n+1} = y_{n-3} + (4h/3) * [2*f_{n-2} - f_{n-1} + 2*f_n]
    y_pred = y_vals[n - 3] + (4.0 * h / 3.0) * (2.0 * F[n - 2] - F[n - 1] + 2.0 * F[n])

    # Milne's Corrector: y_{n+1} = y_{n-1} + (h/3) * [f_{n-1} + 4*f_n + f(x_{n+1}, y_pred)]
    if eps is None:
        # Standard Single Correction Step (Exam Style)
        y_corr = y_vals[n - 1] + (h / 3.0) * (F[n - 1] + 4.0 * F[n] + f(target_x, y_pred))
    else:
        # Iterative Correction until convergence
        prev = y_pred
        iteration = 0
        while True:
            y_corr = y_vals[n - 1] + (h / 3.0) * (F[n - 1] + 4.0 * F[n] + f(target_x, prev))
            iteration += 1
            if abs(y_corr - prev) < eps or iteration >= 25:
                break
            prev = y_corr

    y_vals[n + 1] = y_corr
    F[n + 1] = f(target_x, y_corr)

    print(f"{target_x:<10.4f} | {y_pred:<18.6f} | {y_corr:<18.6f}")

print("=" * 65)
print(f"\nFinal Result: y({xf:.4f}) = {y_vals[-1]:.6f}")